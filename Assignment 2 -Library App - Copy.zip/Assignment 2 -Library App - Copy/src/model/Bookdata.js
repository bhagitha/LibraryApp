const mongoose= require('mongoose');//accessing mongoos package

mongoose.connect('mongodb://localhost:27017/library',{useNewUrlParser: true});// connection string

const Schema=mongoose.Schema;//schema definition

const BookSchema = new Schema({
    title: String,
    author: String,
    genre: String,
    image: String
     //imag will be saved with fil
});

//model creation
var Bookdata = mongoose.model('bookdata',BookSchema);

module.exports = Bookdata;
