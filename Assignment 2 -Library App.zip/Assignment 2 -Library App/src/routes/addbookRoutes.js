const express = require('express');
const addbookRouter=express.Router();

function router(nav){
    //var bodyParser = require("body-parser");
    //addbookRouter.use(bodyParser.urlencoded({extended:false}));

    addbookRouter.get('/',function(req,res){
     res.render("addbook",
        {
            nav,
            title:'Add Book',
        });
    });
    // addbookRouter.post('/books',function(req,res){
    //     var title= req.body.title;
    //     var author=req.body.authorname;
    //     var genre=req.body.genre;


    //     console.log("title : "+title+"author : "+author+"genre"+genre);
    //     res.end("yes");
    // });


    return addbookRouter;
}

module.exports = router;