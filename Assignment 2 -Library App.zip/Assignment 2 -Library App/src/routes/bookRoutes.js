const express = require('express');
const booksRouter=express.Router();

function router(nav){
var books = [
    {
        title:"The Alchemist",
        author:"Paulo Coelho",
        genre:"Graphic Novel",
        img:"book1.jpeg"
    },
    {
        title:"India Positive",
        author:"Chetan Bhagat",
        genre:"Fiction",
        img:"book2.jpeg"
    },
    {
        title:"Wings of fire",
        author:"A P J Abdul Kalam",
        genre:"Auto biography",
        img:"book3.jpeg"
    },
    {
        title:"pathummayude aad",
        author:"Bahseer",
        genre:"Novel",
        img:"book4.jpeg"
    }
]
booksRouter.get('/',function(req,res){
     res.render("books",
        {
            nav,
        
            title:'Books',
            books//books array
        });
    });

booksRouter.get('/:id',function(req,res){
   const id = req.params.id
    res.render("book",
        {
            nav,
            title:'Book',
           book: books[id]
        });
    });
    booksRouter.get('/addbook',function(req,res){
       
         res.render("addbook",
             {
                 nav,
                 title:'Add Book',
                // book: books[id]
             });
         });
     
    return booksRouter;
}

module.exports = router;