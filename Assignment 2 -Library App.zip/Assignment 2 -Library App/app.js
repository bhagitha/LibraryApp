const express = require('express');

// const bodyParser = require("body-parser");
// const router=express.Router();

const app =  express();
const nav = [
    {
        link:'/',name:'Home'
    },
    {
        link:'/books',name:'Books'
    },         
    {
        link:'/author',name:'Authors'
    }
];

const booksRouter = require('./src/routes/bookRoutes')(nav);
const authorRouter = require('./src/routes/authorRoutes')(nav);
const loginRouter = require('./src/routes/loginRoutes')(nav);
const signupRouter = require('./src/routes/signupRoutes')(nav);
const addBookRouter = require('./src/routes/addbookRoutes')(nav);

// app.use(bodyParser.urlencoded({extended:false}));
// app.use(bodyParser.json());

app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views',__dirname+'/src/views');

app.use('/books',booksRouter); //router
app.use('/author',authorRouter); //router
app.use('/login',loginRouter); //router
app.use('/SignUp',signupRouter); //router
app.use('/addbook',addBookRouter); //router

app.get('/',function(req,res){
 res.render("index",
    {
        nav,
        nav1:[
            {link:'/addbook',name:'AddBook'},
            {link:'/login',name:'Login'},
             {link:'/SignUp',name:'SignUp'}],
        title:'Library'
    });
});


// router.get('/addbooks',(req,res)=>{
//     res.sendfile("addbooks");
// });
// router.post('/addbooks',(req,res)=>{
//     var title= req.body.title;
//         var author=req.body.authorname;
//         var genre=req.body.genre;


//         console.log("title : "+title+"author : "+author+"genre"+genre);
//         res.end("yes");
// });


app.listen(5001,()=>{
    console.log("Started on Port 5001 ")
});